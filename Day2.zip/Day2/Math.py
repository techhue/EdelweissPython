
# Function Definition
# a and b arguments to functions
def sum(a, b):
	return str(a) + str(b)

print( sum(10, 20) )
print( sum( "ding", "dong" ) )

ding = "Ding"
dong = "Dong"

print( sum( ding, dong ))


def sub(a, b):
	return a - b

def digits(number):
	digits = []
	while number > 0:
		digits.append(number % 10)
		number = int(number / 10)

	return digits

def classifyNumbers(numbers):
	classifiedNumbers = [ [], [], [] ]
	for number in numbers:
		if number < 50:
			classifiedNumbers[0].append(number)
		#elif number >= 50 and number <= 100:
		elif number <= 100:
			classifiedNumbers[1].append(number)
		else:
			classifiedNumbers[2].append(number)
	return classifiedNumbers

def getCommons(firstList, secondList):
	commonsList = []
	for first in firstList:
		for second in secondList:
			if first == second:
				commonsList.append(first)
	return commonsList


# We are passing values of arguments
# Calling a Function
#.       FunctionName(arg1, arg2)
result = sum(10, 20)
print(result)

result = sum(100, 20)
print(result)

result = sub(10, 20)
print(result)

result = sub(100, 20)
print(result)

result = digits(123456)
print(result)

result = digits(987678)
print(result)

numbers = [10, 22, 11, 99, 88, 80, 70, 60, 111, 200]
result = classifyNumbers(numbers)
print(result)


