
Github Code Link
____________________________________________
https://github.com/techhue/EdelweissPython


How To Do Python Code
____________________________________________
1. Diectly on Python Shell/Intepretor
		python on Command Prompt
		IDLE Shell
2. Write Code In File Hello.py using Favorite Editor
   Run with Following Command
		python Hello.py

Data Types In Python
____________________________________________
	str 	: Python String Type
	int 	: Python Integer Type
	float 	: Python Float Type
	bool	: Python Bool Type

	String Type: Immutable
		String Values can be any Sequence of Characters
		From Python Alphabet Set 
			Starting and Ending with "/'
		+ Operator
			Concatination

		[] Index Operator
			[index] 
				where index can be 0 to len-1
				or -1 to -len

		[::] Slicing and Striding Operator
			[start: end: step]

			where end is not inclusive

			L to R : Default Values Are
				start = 0
				end   = len
				step  = 1

				e.g. [::1] means [0: len: 1]

			R to L : Default Values Are
				start = -1
				end   = -(len+1)
				step  = -1

				e.g. [::-1] means [-1: -(len+1): -1]

		len Operator

	Int Type: Immutable
		Int Values can be any Sequence Using 0-9
		+ Operator
			Integer Arithmatic Addtion

	Float Type: Immutable
		Float Values can be any Sequence Using 0-9
		Seperated By Point . or Exponential Form
		+ Operator
			Floating Point Arithmatic Addtion

	Bool Type: Immutable
		Bool Values can be either False/True Value
		+ Operator
			Integer Arithmatic Addtion
			With Following Value Convertion
				True -> 1 and False -> 0
		Use and, or and not Boolean Operators

	
	Collection Types In Python
	____________________________________________
	tuple : Python Tuple Type

	Tuple Type: Immutable
		Any Type Values Can Be Stored In Tuple
		+ Operator
			Concatination
		[] Index Operator
			[index] 
				where index can be 0 to len-1
				or -1 to -len

		[::] Slicing and Striding Operator
			[start: end: step]

			where end is not inclusive

			L to R : Default Values Are
				start = 0
				end   = len
				step  = 1

				e.g. [::1] means [0: len: 1]

			R to L : Default Values Are
				start = -1
				end   = -(len+1)
				step  = -1

				e.g. [::-1] means [-1: -(len+1): -1]

		len Operator


	List Type: MUTABLE
		Any Type Values Can Be Stored In List
		+ Operator
			Concatination
		[] Index Operator
			[index] 
				where index can be 0 to len-1
				or -1 to -len

		[::] Slicing and Striding Operator
			[start: end: step]

			where end is not inclusive

			L to R : Default Values Are
				start = 0
				end   = len
				step  = 1

				e.g. [::1] means [0: len: 1]

			R to L : Default Values Are
				start = -1
				end   = -(len+1)
				step  = -1

				e.g. [::-1] means [-1: -(len+1): -1]

		len Operator

	Addtion + Operator
		int and int
		float and float
		str and str 
		tuple and tuple

		int and float
			int will be get typecast to float

	Addtion + Operator Doesn't Support
		int and str

Identifier Type in Python
____________________________________________
	Implicitly Inferenced
		From Type of Value Assinged On Right Hand Side
	Binded With Identifier

Type Casting in Python
____________________________________________
	Implicit Type Casting
		Addition of int and float values
			int will be get Implicitly typecast to float

	Explicit Type Casting
		Addition of int and str values
		Addition of float and str values
			int Explicit typecast to str

Escape Sequences
____________________________________________
	Suppress Default Meaning of Characters
	e.g.

	" and ' in Python Means Start/End of String
		\" means Engligh Double Quote
		\' means English Single Quote

	t and n in Python Means English t and n Alphabet
		\t means Tab in Python
		\n means Newline in Python 

	\ means used to Escape 
		\\ means single \ Character






