firstList  = [10, 20, 30, 40, 50, 100, 900, -10]
secondList = [0, 1, 2, 10, 100, 80, 90, 40, -10]

commonsList = []
#notCommonList = []

for first in firstList:
	for second in secondList:
		if first == second:
			commonsList.append(first)

# for first in firstList:
# 	if first in secondList:
# 		commonsList.append(first)


print("Lists Are...")
print(firstList)
print(secondList)

print("Common and notCommonList Are...")
print(commonsList)
#print(notCommonList)
