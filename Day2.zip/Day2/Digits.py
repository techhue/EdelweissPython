
number = 123456789
digits = []

while number > 0:
	digits.append(number % 10)
	number = int(number / 10)

print(digits)
