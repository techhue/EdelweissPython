numbers = [10, 22, 11, 99, 88, 80, 70, 60, 111, 200]
classifiedNumbers = [ [], [], [] ]
# STYLE 1
# for number in numbers:
# 	if number < 50:
# 		classifiedNumbers[0].append(number)
# 	else:
# 		if number >= 50 and number <= 100:
# 			classifiedNumbers[1].append(number)
# 		else:
# 			classifiedNumbers[2].append(number)

# STYLE 2
for number in numbers:
	if number < 50:
		classifiedNumbers[0].append(number)
	#elif number >= 50 and number <= 100:
	elif number <= 100:
		classifiedNumbers[1].append(number)
	else:
		classifiedNumbers[2].append(number)

print(classifiedNumbers)


numbers1 = [10, 22, 11, 99, 88, 80, 70, 60, 111, 200]
numbers2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
result = []

length = len(numbers1)
index = 0
# for number in numbers1:
# 	result.append(number+numbers2[index])
# 	index = index + 1

while index < length:
	result.append( numbers1[index] + numbers2[index] )
	index = index + 1

	if index == 5:
		continue

	print("Hellooo...."+str(index))

	
print(numbers1)
print(numbers2)
print(result)

