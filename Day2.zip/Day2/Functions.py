def sum( *numbers ):
	result = 0
	print(type(numbers))
	for number in numbers:
		result = result + number
	return result

result = sum( 10, 20, 30 )
print(result)

result = sum(10, 20, 30, 40, 50, 60 )
print(result)


#Named Arguments With Default Values
def name(firstName, middleName="", lastName=""):
	result = firstName
	#Input Validation
	if middleName != "":
		result = result + " " + middleName
	#Input Validation
	if lastName != "":
		result = result + " " + lastName

	return result

print( name("Tommy") )
print( name("Ram", "Singh") )
print( name("Ram", middleName = "Singh") )

print( name("Ram", "Singh", "Bahadur") )
print( name("Ram", middleName = "Singh", lastName = "Bahadur") )
print( name("Ram", lastName = "Bahadur") )
#print( name("Ram", marks=(10, 20, 30), lastName = "Bahadur"  ) )

def maxMin( *numbers ):
	max = numbers[0]
	min = numbers[0]
	for number in numbers[1:]:
		if number > max:
			max = number
		elif number < min:
			min = number
	return min, max

result = maxMin(10, 20, -10, 100, 90)
print(result)

def something(**components):
	print( type(components) )
	print(components)
	for item in components.items():
		print(item)

something()
something(ding="Ding")
something(ding="Ding", dong="Dong")
something(ding="Ding", dong="Dong", ting="Ting")

def product( *numbers ):
	result = 1
	print(type(numbers))
	
	for number in numbers:
		result = result * number
	return result


result = product(10, 20, 30)
print(result)

result = product(10, 20, 30, 40, 50, 60 )
print(result)

# {'ding': 'Ding', 'ting': 'Ting', 'dong': 'Dong'}
# ('ding', 'Ding')
# ('ting', 'Ting')
# ('dong', 'Dong')

def something(firstName, *marks, **components):
	name = firstName
	total = 0
	for mark in marks:
		total = total + mark

	for component in components.items():
		print(component)
	
	return name, total

print( something("Gabbar", 20, 30, 40 ))
print( something("Gabbar", 20, 30, 40, 80, 90 ))
print( something("Gabbar", 20, 30, 40, middleName="Singh" ))
print( something("Gabbar", 20, 30, 40, middleName="Singh", lastName="Daku" ))
