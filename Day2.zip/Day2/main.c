#include <stdio.h>

int main() {
	int	 a = 90;
	printf("\nValue of a: %d", a);
}

