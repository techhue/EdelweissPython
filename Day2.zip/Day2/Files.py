# REFACTOR FOLLOWING CODE
# Jo Naam Hai, Wohi Kaam Hai!

def wordCount(file, seperator=" "):
	file = open(file)
	lines = file.readlines()
	frequency = {}
	
	for line in lines:
		words = line.split(seperator)
		for word in words:
			word = word.lower().strip()
			# frequency[word] = frequency.get(word, 0) + 1
			if word in frequency.keys():
				frequency[word] = frequency[word] + 1
			else:
				frequency[word] = 1

	return frequency

result = wordCount("Data.txt")
print(result)

result = wordCount("MarksData.csv", seperator=",")
print(result)



