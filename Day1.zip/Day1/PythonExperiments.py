Python 3.7.4 (default, Jul  9 2019, 18:15:00) 
[Clang 10.0.0 (clang-1000.11.45.5)] on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> greeting = "Hello World!"
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> love = "I Love You!"
>>> 
>>> love = "I Love Youuuuuu!"
>>> 
>>> 
>>> 
>>> print(love)
I Love Youuuuuu!
>>> 
>>> myLove = "Ashywarya Rai"
>>> 
>>> letter = myLove + love
>>> 
>>> letter
'Ashywarya RaiI Love Youuuuuu!'
>>> 
>>> letter = myLove + " " + love
>>> 
>>> letter
'Ashywarya Rai I Love Youuuuuu!'
>>> 
>>> 
>>> type(letter)
<class 'str'>
>>> 
>>> type(greeting)
<class 'str'>
>>> 
>>> 
>>> 
>>> anotherGreeting = 'Hello!, How are you?'
>>> 
>>> 
>>> anotherGreeting
'Hello!, How are you?'
>>> type(anotherGreeting)
<class 'str'>
>>> 
>>> 
>>> anotherGreeting
'Hello!, How are you?'
>>> 
>>> print(anotherGreeting)
Hello!, How are you?
>>> 
>>> 234Something = "Ding Dong"
  File "<stdin>", line 1
    234Something = "Ding Dong"
               ^
SyntaxError: invalid syntax
>>> 
>>> 
>>> __Something = "Ding Dong"
>>> 
>>> 
>>> 
>>> __Something
'Ding Dong'
>>> 
>>> 
>>> 
>>> something = "Ding Dong"
>>> Something = "Ming Mong"
>>> 
>>> something
'Ding Dong'
>>> 
>>> Something
'Ming Mong'
>>> 
>>> 
>>> dir()
['Something', '__Something', '__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'anotherGreeting', 'greeting', 'letter', 'love', 'myLove', 'something']
>>> 
>>> 
>>> dir(__builtins__)
['ArithmeticError', 'AssertionError', 'AttributeError', 'BaseException', 'BlockingIOError', 'BrokenPipeError', 'BufferError', 'BytesWarning', 'ChildProcessError', 'ConnectionAbortedError', 'ConnectionError', 'ConnectionRefusedError', 'ConnectionResetError', 'DeprecationWarning', 'EOFError', 'Ellipsis', 'EnvironmentError', 'Exception', 'False', 'FileExistsError', 'FileNotFoundError', 'FloatingPointError', 'FutureWarning', 'GeneratorExit', 'IOError', 'ImportError', 'ImportWarning', 'IndentationError', 'IndexError', 'InterruptedError', 'IsADirectoryError', 'KeyError', 'KeyboardInterrupt', 'LookupError', 'MemoryError', 'ModuleNotFoundError', 'NameError', 'None', 'NotADirectoryError', 'NotImplemented', 'NotImplementedError', 'OSError', 'OverflowError', 'PendingDeprecationWarning', 'PermissionError', 'ProcessLookupError', 'RecursionError', 'ReferenceError', 'ResourceWarning', 'RuntimeError', 'RuntimeWarning', 'StopAsyncIteration', 'StopIteration', 'SyntaxError', 'SyntaxWarning', 'SystemError', 'SystemExit', 'TabError', 'TimeoutError', 'True', 'TypeError', 'UnboundLocalError', 'UnicodeDecodeError', 'UnicodeEncodeError', 'UnicodeError', 'UnicodeTranslateError', 'UnicodeWarning', 'UserWarning', 'ValueError', 'Warning', 'ZeroDivisionError', '_', '__build_class__', '__debug__', '__doc__', '__import__', '__loader__', '__name__', '__package__', '__spec__', 'abs', 'all', 'any', 'ascii', 'bin', 'bool', 'breakpoint', 'bytearray', 'bytes', 'callable', 'chr', 'classmethod', 'compile', 'complex', 'copyright', 'credits', 'delattr', 'dict', 'dir', 'divmod', 'enumerate', 'eval', 'exec', 'exit', 'filter', 'float', 'format', 'frozenset', 'getattr', 'globals', 'hasattr', 'hash', 'help', 'hex', 'id', 'input', 'int', 'isinstance', 'issubclass', 'iter', 'len', 'license', 'list', 'locals', 'map', 'max', 'memoryview', 'min', 'next', 'object', 'oct', 'open', 'ord', 'pow', 'print', 'property', 'quit', 'range', 'repr', 'reversed', 'round', 'set', 'setattr', 'slice', 'sorted', 'staticmethod', 'str', 'sum', 'super', 'tuple', 'type', 'vars', 'zip']
>>> 
>>> 
>>> 
>>> greeting = "Hello World!"
>>> 
>>> greeting
'Hello World!'
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> 
>>> 
>>> 
>>> a = 100
>>> b = 10
>>> type(a)
<class 'int'>
>>> 
>>> type(b)
<class 'int'>
>>> 
>>> c = a + b
>>> 
>>> c
110
>>> 
>>> type(c)
<class 'int'>
>>> 
>>> 
>>> 
>>> dir()
['Something', '__Something', '__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'a', 'anotherGreeting', 'b', 'c', 'greeting', 'letter', 'love', 'myLove', 'something']
>>> 
>>> 
>>> 
>>> 
>>> f1 = 9.89
>>> f2 = 20.10
>>> 
>>> ff = f1 + f2
>>> ff
29.990000000000002
>>> 
>>> type(f1)
<class 'float'>
>>> type(f2)
<class 'float'>
>>> 
>>> type(ff)
<class 'float'>
>>> 
>>> print(a, b)
100 10
>>> 
>>> f1
9.89
>>> 
>>> f2
20.1
>>> 
>>> f1+f2
29.990000000000002
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> a
100
>>> 
>>> greeting + a
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: can only concatenate str (not "int") to str
>>> 
>>> 
>>> 
>>> print = "Ching Chonk"
>>> 
>>> print(greeting)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'str' object is not callable
>>> 
>>> print
'Ching Chonk'
>>> 
>>> dir()
['Something', '__Something', '__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'a', 'anotherGreeting', 'b', 'c', 'f1', 'f2', 'ff', 'greeting', 'letter', 'love', 'myLove', 'print', 'something']
>>> 
>>> 
>>> del print
>>> 
>>> dir()
['Something', '__Something', '__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'a', 'anotherGreeting', 'b', 'c', 'f1', 'f2', 'ff', 'greeting', 'letter', 'love', 'myLove', 'something']
>>> 
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 


Python 3.7.4 (default, Jul  9 2019, 18:15:00) 
[Clang 10.0.0 (clang-1000.11.45.5)] on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> greeting = "Hello World!"
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> 
>>> Print(greeting)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'Print' is not defined
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> 
>>> 
>>> a = 10
>>> f = 9.8
>>> 
>>> a + f
19.8
>>> 
>>> type(a)
<class 'int'>
>>> type(f)
<class 'float'>
>>> 
>>> ff = a + f
>>> 
>>> type(ff)
<class 'float'>
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting + a
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: can only concatenate str (not "int") to str
>>> 
>>> greeting + f
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: can only concatenate str (not "float") to str
>>> 
>>> greeting + str(a)
'Hello World!10'
>>> 
>>> 
>>> 
>>> 

Intelligenes-MacBook-Pro:Edelweiss.DataAnalytics2 intelligene$ python3
Python 3.7.4 (default, Jul  9 2019, 18:15:00) 
[Clang 10.0.0 (clang-1000.11.45.5)] on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> greeting = "Hello World!"
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> 
>>> Print(greeting)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'Print' is not defined
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> 
>>> 
>>> a = 10
>>> f = 9.8
>>> 
>>> a + f
19.8
>>> 
>>> type(a)
<class 'int'>
>>> type(f)
<class 'float'>
>>> 
>>> ff = a + f
>>> 
>>> type(ff)
<class 'float'>
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting + a
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: can only concatenate str (not "int") to str
>>> 
>>> greeting + f
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: can only concatenate str (not "float") to str
>>> 
>>> greeting + str(a)
'Hello World!10'
>>> 
>>> 
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> int(greeting)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: invalid literal for int() with base 10: 'Hello World!'
>>> 
>>> 
>>> 
>>> something = "980"
>>> 
>>> somethingValue = int(something)
>>> 
>>> somethingValue
980
>>> 
>>> type(somethingValue)
<class 'int'>
>>> 
>>> type(something)
<class 'str'>
>>> 
>>> 
>>> 
>>> f = 90.9
>>> 
>>> somethingMore = str()
>>> 
>>> 
>>> somethingMore
''
>>> 
>>> somethingMore = str(f)
>>> 
>>> somethingMore
'90.9'
>>> 
>>> 
>>> 
>>> something = "90.9"
>>> 
>>> somethingValue = int(something)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: invalid literal for int() with base 10: '90.9'
>>> 
>>> 
>>> somethingValue = float(something)
>>> 
>>> somethingValue
90.9
>>> 
>>> 
>>> 
>>> a = 90
>>> 
>>> 
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> 
>>> 
>>> a = False
>>> 
>>> a
False
>>> 
>>> type(A)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'A' is not defined
>>> 
>>> type(A)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'A' is not defined
>>> 
>>> type(a)
<class 'bool'>
>>> 
>>> 
>>> b = False
>>> 
>>> type(b)
<class 'bool'>
>>> 
>>> 
>>> 
>>> a
False
>>> b
False
>>> 
>>> a = True
>>> 
>>> a
True
>>> 
>>> b
False
>>> 
>>> a + b
1
>>> 
>>> c = a + b
>>> 
>>> type(c)
<class 'int'>
>>> 
>>> 
>>> value = 90
>>> 
>>> type(value) 
<class 'int'>
>>> 
>>> a
True
>>> type(a)
<class 'bool'>
>>> value
90
>>> type(value)
<class 'int'>
>>> 
>>> result = value + a
>>> 
>>> result
91
>>> 
>>> type(result)
<class 'int'>
>>> 
>>> 
>>> 
>>> first = True
>>> second = False
>>> 
>>> first and second
False
>>> 
>>> first or second
True
>>> 
>>> not first
False
>>> 
>>> not second
True
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greetingUpper = greeting.upper()
>>> 
>>> greetingUpper
'HELLO WORLD!'
>>> 
>>> greetingLower = greeting.lower()
>>> 
>>> greetingLower
'hello world!'
>>> 
>>> greeting.title()
'Hello World!'
>>> 
>>> 
>>> dir(greeting)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> greeting.upper()
'HELLO WORLD!'
>>> 
>>> greeting
'Hello World!'
>>> 
>>> 
>>> greeting = greeting.upper()
>>> 
>>> greeting
'HELLO WORLD!'
>>> 
>>> 
>>> 
>>> greeting = greeting.title()
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting.split()
['Hello', 'World!']
>>> 
>>> soemthing = "Ding Dong Ming Mong\tTing Tong\nZing Zong"
>>> 
>>> something
'90.9'
>>> 
>>> soemthing
'Ding Dong Ming Mong\tTing Tong\nZing Zong'
>>> 
>>> 
>>> print(soemthing)
Ding Dong Ming Mong	Ting Tong
Zing Zong
>>> 
>>> 
>>> 
>>> 
>>> soemthing.split()
['Ding', 'Dong', 'Ming', 'Mong', 'Ting', 'Tong', 'Zing', 'Zong']
>>> 
>>> 
>>> 
>>> soemthing.split("g")
['Din', ' Don', ' Min', ' Mon', '\tTin', ' Ton', '\nZin', ' Zon', '']
>>> 
>>> 
>>> header = "SNo,Principle,Interest,Penality,"
>>> 
>>> header.split()
['SNo,Principle,Interest,Penality,']
>>> 
>>> header.split(",")
['SNo', 'Principle', 'Interest', 'Penality', '']
>>> 
>>> header.lsplit(",")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AttributeError: 'str' object has no attribute 'lsplit'
>>> 
>>> header.split(",")
['SNo', 'Principle', 'Interest', 'Penality', '']
>>> 
>>> dir(header)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> heade4r
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'heade4r' is not defined
>>> header
'SNo,Principle,Interest,Penality,'
>>> 
>>> 
>>> header = "SNo,Principle,Interest,Penality, "
>>> header.split()
['SNo,Principle,Interest,Penality,']
>>> 
>>> header.split(",")
['SNo', 'Principle', 'Interest', 'Penality', ' ']
>>> 
>>> 
>>> header1 = "SNo,Principle,Interest,Penality,"
>>> header1.split(",")
['SNo', 'Principle', 'Interest', 'Penality', '']
>>> 
>>> soemthing
'Ding Dong Ming Mong\tTing Tong\nZing Zong'
>>> 
>>> soemthing.split("g")
['Din', ' Don', ' Min', ' Mon', '\tTin', ' Ton', '\nZin', ' Zon', '']
>>> 
>>> result = soemthing.split("g")
>>> 
>>> print(result)
['Din', ' Don', ' Min', ' Mon', '\tTin', ' Ton', '\nZin', ' Zon', '']
>>> 
>>> result = soemthing.split()
>>> 
>>> result
['Ding', 'Dong', 'Ming', 'Mong', 'Ting', 'Tong', 'Zing', 'Zong']
>>> 
>>> 
>>> sentence = "He asked me, "How are you?"
  File "<stdin>", line 1
    sentence = "He asked me, "How are you?"
                                ^
SyntaxError: invalid syntax
>>> 
>>> 
>>> 
>>> sentence = "He asked me, "How are you?""
  File "<stdin>", line 1
    sentence = "He asked me, "How are you?""
                                ^
SyntaxError: invalid syntax
>>> 
>>> sentence = "He asked me, \"How are you?\""
>>> 
>>> senence
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'senence' is not defined
>>> 
>>> sentence
'He asked me, "How are you?"'
>>> 
>>> 
>>> 
>>> onceMore = "Ding Dong \nMing Mong"
>>> 
>>> onceMore
'Ding Dong \nMing Mong'
>>> 
>>> print(onceMore)
Ding Dong 
Ming Mong
>>> 
>>> onceMore = "Ding Dong \tMing Mong"
>>> 
>>> onceMore
'Ding Dong \tMing Mong'
>>> 
>>> print(onceMore)
Ding Dong 	Ming Mong
>>> 
>>> 
>>> 
>>> 
>>> DilMangeMore = "Ding Dong, 'Dil Mange More'"
>>> 
>>> DilMangeMore
"Ding Dong, 'Dil Mange More'"
>>> 
>>> 
>>> DilMangeMore = 'Ding Dong, \'Dil Mange More\''
>>> DilMangeMore
"Ding Dong, 'Dil Mange More'"
>>> 
>>> 
>>> something = 'Ding Dong \tMing Mong\n Ting Tong'
>>> 
>>> 
>>> something = 'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> something
'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> 
>>> print(something)
Ding\ Dong 	Ming Mong
 Ting\ Tong
>>> 
>>> something.split("\")
  File "<stdin>", line 1
    something.split("\")
                       ^
SyntaxError: EOL while scanning string literal
>>> 
>>> something.split("\\")
['Ding', ' Dong \tMing Mong\n Ting', ' Tong']
>>> 
>>> 
>>> 
>>> 
>>> something
'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[0]
'H'
>>> 
>>> greeting[1]
'e'
>>> greeting[2]
'l'
>>> greeting[3]
'l'
>>> 
>>> greeting[4]
'o'
>>> greeting[5]
' '
>>> greeting[6]
'W'
>>> greeting[7]
'o'
>>> greeting[8]
'r'
>>> greeting[9]
'l'
>>> greeting[10]
'd'
>>> greeting[11]
'!'
>>> greeting[12]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> len(greeting)
12
>>> 
>>> l = len(greeting)
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[l]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[-1]
'!'
>>> 
>>> greeting[-2]
'd'
>>> greeting[-3]
'l'
>>> 
>>> greeting[-l]
'H'
>>> 
>>> greeting[-(l+1)]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> len(greeting)
12
>>> 
>>> l = len(greeting)
>>> 
>>> l
12
>>> 
>>> something
'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> 
>>> 
>>> something[0]
'D'
>>> something[1]
'i'
>>> something[2]
'n'
>>> something[3]
'g'
>>> something[4]
'\\'
>>> 
>>> something[5]
' '
>>> 
>>> 

Python 3.7.4 (default, Jul  9 2019, 18:15:00) 
[Clang 10.0.0 (clang-1000.11.45.5)] on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>> quit()
Intelligenes-MacBook-Pro:Edelweiss.DataAnalytics2 intelligene$ 
Intelligenes-MacBook-Pro:Edelweiss.DataAnalytics2 intelligene$ python3 Hello.py 
Hello World!
Intelligenes-MacBook-Pro:Edelweiss.DataAnalytics2 intelligene$ 
Intelligenes-MacBook-Pro:Edelweiss.DataAnalytics2 intelligene$ 
Intelligenes-MacBook-Pro:Edelweiss.DataAnalytics2 intelligene$ 
Intelligenes-MacBook-Pro:Edelweiss.DataAnalytics2 intelligene$ 
Intelligenes-MacBook-Pro:Edelweiss.DataAnalytics2 intelligene$ python3
Python 3.7.4 (default, Jul  9 2019, 18:15:00) 
[Clang 10.0.0 (clang-1000.11.45.5)] on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> greeting = "Hello World!"
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> 
>>> Print(greeting)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'Print' is not defined
>>> 
>>> print(greeting)
Hello World!
>>> 
>>> 
>>> 
>>> a = 10
>>> f = 9.8
>>> 
>>> a + f
19.8
>>> 
>>> type(a)
<class 'int'>
>>> type(f)
<class 'float'>
>>> 
>>> ff = a + f
>>> 
>>> type(ff)
<class 'float'>
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting + a
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: can only concatenate str (not "int") to str
>>> 
>>> greeting + f
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: can only concatenate str (not "float") to str
>>> 
>>> greeting + str(a)
'Hello World!10'
>>> 
>>> 
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> int(greeting)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: invalid literal for int() with base 10: 'Hello World!'
>>> 
>>> 
>>> 
>>> something = "980"
>>> 
>>> somethingValue = int(something)
>>> 
>>> somethingValue
980
>>> 
>>> type(somethingValue)
<class 'int'>
>>> 
>>> type(something)
<class 'str'>
>>> 
>>> 
>>> 
>>> f = 90.9
>>> 
>>> somethingMore = str()
>>> 
>>> 
>>> somethingMore
''
>>> 
>>> somethingMore = str(f)
>>> 
>>> somethingMore
'90.9'
>>> 
>>> 
>>> 
>>> something = "90.9"
>>> 
>>> somethingValue = int(something)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: invalid literal for int() with base 10: '90.9'
>>> 
>>> 
>>> somethingValue = float(something)
>>> 
>>> somethingValue
90.9
>>> 
>>> 
>>> 
>>> a = 90
>>> 
>>> 
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> 
>>> 
>>> a = False
>>> 
>>> a
False
>>> 
>>> type(A)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'A' is not defined
>>> 
>>> type(A)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'A' is not defined
>>> 
>>> type(a)
<class 'bool'>
>>> 
>>> 
>>> b = False
>>> 
>>> type(b)
<class 'bool'>
>>> 
>>> 
>>> 
>>> a
False
>>> b
False
>>> 
>>> a = True
>>> 
>>> a
True
>>> 
>>> b
False
>>> 
>>> a + b
1
>>> 
>>> c = a + b
>>> 
>>> type(c)
<class 'int'>
>>> 
>>> 
>>> value = 90
>>> 
>>> type(value) 
<class 'int'>
>>> 
>>> a
True
>>> type(a)
<class 'bool'>
>>> value
90
>>> type(value)
<class 'int'>
>>> 
>>> result = value + a
>>> 
>>> result
91
>>> 
>>> type(result)
<class 'int'>
>>> 
>>> 
>>> 
>>> first = True
>>> second = False
>>> 
>>> first and second
False
>>> 
>>> first or second
True
>>> 
>>> not first
False
>>> 
>>> not second
True
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greetingUpper = greeting.upper()
>>> 
>>> greetingUpper
'HELLO WORLD!'
>>> 
>>> greetingLower = greeting.lower()
>>> 
>>> greetingLower
'hello world!'
>>> 
>>> greeting.title()
'Hello World!'
>>> 
>>> 
>>> dir(greeting)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> greeting.upper()
'HELLO WORLD!'
>>> 
>>> greeting
'Hello World!'
>>> 
>>> 
>>> greeting = greeting.upper()
>>> 
>>> greeting
'HELLO WORLD!'
>>> 
>>> 
>>> 
>>> greeting = greeting.title()
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting.split()
['Hello', 'World!']
>>> 
>>> soemthing = "Ding Dong Ming Mong\tTing Tong\nZing Zong"
>>> 
>>> something
'90.9'
>>> 
>>> soemthing
'Ding Dong Ming Mong\tTing Tong\nZing Zong'
>>> 
>>> 
>>> print(soemthing)
Ding Dong Ming Mong	Ting Tong
Zing Zong
>>> 
>>> 
>>> 
>>> 
>>> soemthing.split()
['Ding', 'Dong', 'Ming', 'Mong', 'Ting', 'Tong', 'Zing', 'Zong']
>>> 
>>> 
>>> 
>>> soemthing.split("g")
['Din', ' Don', ' Min', ' Mon', '\tTin', ' Ton', '\nZin', ' Zon', '']
>>> 
>>> 
>>> header = "SNo,Principle,Interest,Penality,"
>>> 
>>> header.split()
['SNo,Principle,Interest,Penality,']
>>> 
>>> header.split(",")
['SNo', 'Principle', 'Interest', 'Penality', '']
>>> 
>>> header.lsplit(",")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AttributeError: 'str' object has no attribute 'lsplit'
>>> 
>>> header.split(",")
['SNo', 'Principle', 'Interest', 'Penality', '']
>>> 
>>> dir(header)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> heade4r
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'heade4r' is not defined
>>> header
'SNo,Principle,Interest,Penality,'
>>> 
>>> 
>>> header = "SNo,Principle,Interest,Penality, "
>>> header.split()
['SNo,Principle,Interest,Penality,']
>>> 
>>> header.split(",")
['SNo', 'Principle', 'Interest', 'Penality', ' ']
>>> 
>>> 
>>> header1 = "SNo,Principle,Interest,Penality,"
>>> header1.split(",")
['SNo', 'Principle', 'Interest', 'Penality', '']
>>> 
>>> soemthing
'Ding Dong Ming Mong\tTing Tong\nZing Zong'
>>> 
>>> soemthing.split("g")
['Din', ' Don', ' Min', ' Mon', '\tTin', ' Ton', '\nZin', ' Zon', '']
>>> 
>>> result = soemthing.split("g")
>>> 
>>> print(result)
['Din', ' Don', ' Min', ' Mon', '\tTin', ' Ton', '\nZin', ' Zon', '']
>>> 
>>> result = soemthing.split()
>>> 
>>> result
['Ding', 'Dong', 'Ming', 'Mong', 'Ting', 'Tong', 'Zing', 'Zong']
>>> 
>>> 
>>> sentence = "He asked me, "How are you?"
  File "<stdin>", line 1
    sentence = "He asked me, "How are you?"
                                ^
SyntaxError: invalid syntax
>>> 
>>> 
>>> 
>>> sentence = "He asked me, "How are you?""
  File "<stdin>", line 1
    sentence = "He asked me, "How are you?""
                                ^
SyntaxError: invalid syntax
>>> 
>>> sentence = "He asked me, \"How are you?\""
>>> 
>>> senence
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'senence' is not defined
>>> 
>>> sentence
'He asked me, "How are you?"'
>>> 
>>> 
>>> 
>>> onceMore = "Ding Dong \nMing Mong"
>>> 
>>> onceMore
'Ding Dong \nMing Mong'
>>> 
>>> print(onceMore)
Ding Dong 
Ming Mong
>>> 
>>> onceMore = "Ding Dong \tMing Mong"
>>> 
>>> onceMore
'Ding Dong \tMing Mong'
>>> 
>>> print(onceMore)
Ding Dong 	Ming Mong
>>> 
>>> 
>>> 
>>> 
>>> DilMangeMore = "Ding Dong, 'Dil Mange More'"
>>> 
>>> DilMangeMore
"Ding Dong, 'Dil Mange More'"
>>> 
>>> 
>>> DilMangeMore = 'Ding Dong, \'Dil Mange More\''
>>> DilMangeMore
"Ding Dong, 'Dil Mange More'"
>>> 
>>> 
>>> something = 'Ding Dong \tMing Mong\n Ting Tong'
>>> 
>>> 
>>> something = 'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> something
'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> 
>>> print(something)
Ding\ Dong 	Ming Mong
 Ting\ Tong
>>> 
>>> something.split("\")
  File "<stdin>", line 1
    something.split("\")
                       ^
SyntaxError: EOL while scanning string literal
>>> 
>>> something.split("\\")
['Ding', ' Dong \tMing Mong\n Ting', ' Tong']
>>> 
>>> 
>>> 
>>> 
>>> something
'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[0]
'H'
>>> 
>>> greeting[1]
'e'
>>> greeting[2]
'l'
>>> greeting[3]
'l'
>>> 
>>> greeting[4]
'o'
>>> greeting[5]
' '
>>> greeting[6]
'W'
>>> greeting[7]
'o'
>>> greeting[8]
'r'
>>> greeting[9]
'l'
>>> greeting[10]
'd'
>>> greeting[11]
'!'
>>> greeting[12]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> len(greeting)
12
>>> 
>>> l = len(greeting)
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[l]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[-1]
'!'
>>> 
>>> greeting[-2]
'd'
>>> greeting[-3]
'l'
>>> 
>>> greeting[-l]
'H'
>>> 
>>> greeting[-(l+1)]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> len(greeting)
12
>>> 
>>> l = len(greeting)
>>> 
>>> l
12
>>> 
>>> something
'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> 
>>> 
>>> something[0]
'D'
>>> something[1]
'i'
>>> something[2]
'n'
>>> something[3]
'g'
>>> something[4]
'\\'
>>> 
>>> something[5]
' '
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> something
'Ding\\ Dong \tMing Mong\n Ting\\ Tong'
>>> 
>>> 
>>> len(something)
33
>>> 
>>> 
>>> 
>>> something.split("in")
['D', 'g\\ Dong \tM', 'g Mong\n T', 'g\\ Tong']
>>> 
>>> 
>>> 
>>> 
>>> some = something.split("in")
>>> len(some)
4
>>> 
>>> 
>>> type(something)
<class 'str'>
>>> 
>>> type(some)
<class 'list'>
>>> 
>>> 
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[0]
'H'
>>> 
>>> l = len(greeting)
>>> 
>>> greeting[l]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> greeting[l-1]
'!'
>>> 
>>> greeting[-1]
'!'
>>> 
>>> greeting[-l]
'H'
>>> 
>>> greeting[-13]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range
>>> 
>>> 
>>> 
>>> greeting[2:6]
'llo '
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting[0:l-1]
'Hello World'
>>> 
>>> greeting[0:l]
'Hello World!'
>>> 
>>> greeting[:]
'Hello World!'
>>> 
>>> 
>>> greeting[::2]
'HloWrd'
>>> 
>>> greeting[::3]
'HlWl'
>>> 
>>> 
>>> greeting[::-1]
'!dlroW olleH'
>>> greeting[-10: -5]
'llo W'
>>> greeting[::]
'Hello World!'
>>> 
>>> 
>>> 
>>> greeting[:-2:-4]
'!'
>>> 
>>> 
>>> 
>>> 
>>> greeting[::-1]
'!dlroW olleH'
>>> 
>>> 
>>> l = len(greeting)
>>> 
>>> greeting[:-l:-1]
'!dlroW olle'
>>> 
>>> 
>>> 
>>> greeting[:-(l+1):-1]
'!dlroW olleH'
>>> 
>>> 
>>> greeting[::]
'Hello World!'
>>> greeting
'Hello World!'
>>> 
>>> 
>>> greeting[0: -l: 1]
''
>>> 
>>> greeting[0: l: 1]
'Hello World!'
>>> 
>>> greeting[::2]
'HloWrd'
>>> 
>>> 
>>> 
>>> dir(greeting)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> 
>>> dir(str)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting.startswith("Hello")
True
>>> 
>>> greeting.endswith("Hello")
False
>>> 
>>> greeting.endswith("World")
False
>>> 
>>> greeting.endswith("World!")
True
>>> 
>>> 
>>> 
>>> something = "     Ding Dong Ming Mong      "
>>> 
>>> something
'     Ding Dong Ming Mong      '
>>> 
>>> print(something)
     Ding Dong Ming Mong      
>>> 
>>> 
>>> 
>>> 
>>> 
>>> something1 = "Ding Dong Ming Mong"
>>> 
>>> something == something1
False
>>> 
>>> something.strip()
'Ding Dong Ming Mong'
>>> 
>>> 
>>> 
>>> 
>>> something.strip() == something1
True
>>> 
>>> 
>>> 
>>> 
>>> something.lstrip()
'Ding Dong Ming Mong      '
>>> 
>>> 
>>> something.rstrip()
'     Ding Dong Ming Mong'
>>> 
>>> 
>>> something.strip()
'Ding Dong Ming Mong'
>>> 
>>> 
>>> 
>>> dir(str)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting.find("llo")
2
>>> 
>>> 
>>> greeting.find("Llo")
-1
>>> 
>>> 
>>> 
>>> greeting.index("llo")
2
>>> 
>>> 
>>> greeting.index("Llo")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: substring not found
>>> 
>>> 
>>> 
>>> greeting
'Hello World!'
>>> 
>>> greeting = greeting + "Hi Modi! "
>>> 
>>> greeting
'Hello World!Hi Modi! '
>>> 
>>> greeting
'Hello World!Hi Modi! '
>>> 
>>> 
>>> 
>>> 
>>> 
>>> greeting.replace("Modi", "Sushma Swaraj")
'Hello World!Hi Sushma Swaraj! '
>>> 
>>> 
>>> 
>>> 
>>> greeting.index("llo")
2
>>> 
>>> 
>>> newString = "Ding Dong Ming Mong Ding Dong Ming Mong"
>>> 
>>> newString.find(
... "Dong")
5
>>> 
>>> 
>>> newString.find("Dong", 0, 10)
5
>>> 
>>> newString.find("Dong", 6, 10)
-1
>>> 
>>> 
>>> newString.find("Dong", 6, 50)
25
>>> 
>>> 
>>> 
>>> help(str.find)

>>> help("".find)

>>> 
>>> 
>>> help(greeting.find)

>>> help(greeting.find)

>>> help(greeting.find)

>>> 
>>> 
>>> dir(str)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> greeting
'Hello World!Hi Modi! '
>>> 
>>> greeting.center(80)
'                             Hello World!Hi Modi!                               '
>>> 
>>> 
>>> 
>>> greeting.zfill(80)
'00000000000000000000000000000000000000000000000000000000000Hello World!Hi Modi! '
>>> 
>>> 
>>> greeting.zfill(80, "#")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: zfill() takes exactly one argument (2 given)
>>> 
>>> 
>>> 
>>> 
>>> greeting.zfill(80)
'00000000000000000000000000000000000000000000000000000000000Hello World!Hi Modi! '
>>> 
>>> 
>>> 
>>> 
>>> dir(str)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> 
>>> 
>>> greeting
'Hello World!Hi Modi! '
>>> 
>>> greeting.ljust(50)
'Hello World!Hi Modi!                              '
>>> 
>>> greeting.rjust(50)
'                             Hello World!Hi Modi! '
>>> 
>>> 
>>> 
>>> dir("".ljust)
['__call__', '__class__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__le__', '__lt__', '__module__', '__name__', '__ne__', '__new__', '__qualname__', '__reduce__', '__reduce_ex__', '__repr__', '__self__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '__text_signature__']
>>> h
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'h' is not defined
>>> 
>>> help("".ljust)

>>> 
>>> 
>>> greeting.rjust(50, "#")
'#############################Hello World!Hi Modi! '
>>> 
>>> 
>>> 
>>> 
>>> 
>>> greeting.ljust(50, "#")
'Hello World!Hi Modi! #############################'
>>> 
>>> 
>>> 
>>> 
>>> dir(greeting)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> 
>>> something = 
  File "<stdin>", line 1
    something = 
               ^
SyntaxError: invalid syntax
>>> something = "Ding Dong \n Ming Mong \n Ting Tong"
>>> 
>>> something
'Ding Dong \n Ming Mong \n Ting Tong'
>>> 
>>> 
>>> 
>>> print(something)
Ding Dong 
 Ming Mong 
 Ting Tong
>>> 
>>> 
>>> 
>>> lines = something.split("\n")
>>> 
>>> lines
['Ding Dong ', ' Ming Mong ', ' Ting Tong']
>>> 
>>> 
>>> 
>>> lines = something.split()
>>> 
>>> liens
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'liens' is not defined
>>> lines
['Ding', 'Dong', 'Ming', 'Mong', 'Ting', 'Tong']
>>> 
>>> lines = something.split("\n")
>>> 
>>> lines
['Ding Dong ', ' Ming Mong ', ' Ting Tong']
>>> 
>>> 
>>> something.splitlines()
['Ding Dong ', ' Ming Mong ', ' Ting Tong']
>>> 
>>> 
>>> dir(something)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> 
>>> something
'Ding Dong \n Ming Mong \n Ting Tong'
>>> 
>>> 
>>> something.count("Ding")
1
>>> 
>>> 
>>> something.count("ing")
3
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> t = (10, 20, 30, 40, 50, 60, 70, 80, 90)
>>> 
>>> t
(10, 20, 30, 40, 50, 60, 70, 80, 90)
>>> 
>>> type(t)
<class 'tuple'>
>>> 
>>> t[0]
10
>>> t[1]
20
>>> 
>>> 
>>> t[2]
30
>>> 
>>> t[4]
50
>>> 
>>> l = len(t)
>>> 
>>> l
9
>>> 
>>> t
(10, 20, 30, 40, 50, 60, 70, 80, 90)
>>> 
>>> t.count()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: count() takes exactly one argument (0 given)
>>> 
>>> t.count(100)
0
>>> 
>>> t.count("")
0
>>> 
>>> greeting
'Hello World!Hi Modi! '
>>> 
>>> greeting.count("")
22
>>> 
>>> len(greeting)
21
>>> 
>>> emptyString  = ""
>>> len(emptyString)
0
>>> 
>>> emptyString.count("")
1
>>> 
>>> greeting.count("")
22
>>> 
>>> 
>>> 
>>> 
>>> 
>>> a = int()
>>> 
>>> a
0
>>> 
>>> f = float()
>>> 
>>> f
0.0
>>> 
>>> type(f)
<class 'float'>
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> s = str()
>>> s
''
>>> 
>>> b = bool()
>>> type(b)
<class 'bool'>
>>> b
False
>>> 
>>> a
0
>>> type(a)
<class 'int'>
>>> bool(a)
False
>>> 
>>> f
0.0
>>> type(f)
<class 'float'>
>>> 
>>> bool(f)
False
>>> 
>>> s
''
>>> 
>>> bool(s)
False
>>> 
>>> 
>>> 
>>> b
False
>>> 
>>> bool(b)
False
>>> 
>>> 
>>> a = 9
>>> 
>>> bool(a)
True
>>> 
>>> s = "Ding"
>>> 
>>> bool(s)
True
>>> 
>>> f = 9.9
>>> 
>>> bool(f)
True
>>> 
>>> 
>>> 
>>> 
>>> t
(10, 20, 30, 40, 50, 60, 70, 80, 90)
>>> 
>>> type(t)
<class 'tuple'>
>>> 
>>> t[2:5]
(30, 40, 50)
>>> 
>>> t[2:8]
(30, 40, 50, 60, 70, 80)
>>> 
>>> t[2:8:2]
(30, 50, 70)
>>> 
>>> 
>>> 
>>> 
>>> t[::-1]
(90, 80, 70, 60, 50, 40, 30, 20, 10)
>>> 
>>> 
>>> 
>>> 
>>> dir(tuple)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> t 
(10, 20, 30, 40, 50, 60, 70, 80, 90)
>>> 
>>> tt = (10, 20, 30, "Ding", "Dong")
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> 
>>> tt[0]
10
>>> 
>>> tt[1]
20
>>> tt[2]
30
>>> tt[3]
'Ding'
>>> 
>>> tt[4]
'Dong'
>>> 
>>> 
>>> 
>>> sheet = ( (1, "Ding", "Dong"), (2, "Ming", "Mong"), (3, "Ting", "Tong"))
>>> 
>>> sheet
((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong'))
>>> 
>>> sheet[0]
(1, 'Ding', 'Dong')
>>> 
>>> sheet[1]
(2, 'Ming', 'Mong')
>>> 
>>> sheet[2]
(3, 'Ting', 'Tong')
>>> 
>>> sheet[0][0]
1
>>> 
>>> sheet[0][1]
'Ding'
>>> sheet[0][2]
'Dong'
>>> 
>>> sheet[1][2]
'Mong'
>>> 
>>> tt
(10, 20, 30, 'Ding', 'Dong')
>>> 
>>> tt[4]
'Dong'
>>> 
>>> tt[4][0]
'D'
>>> tt[4][1]
'o'
>>> 
>>> tt = (10, 20, 30, 'Ding', '  Dong   ')
>>> 
>>> tt
(10, 20, 30, 'Ding', '  Dong   ')
>>> 
>>> tt[4]
'  Dong   '
>>> 
>>> tt[4].strip)_
  File "<stdin>", line 1
    tt[4].strip)_
               ^
SyntaxError: invalid syntax
>>> tt[4].strip()
'Dong'
>>> 
>>> 
>>> tt[4].split("on")
['  D', 'g   ']
>>> 
>>> tt[4].split("on")
['  D', 'g   ']
>>> 
>>> 
>>> tt[4].strip().split("on")
['D', 'g']
>>> 
>>> 
>>> 
>>> 
>>> tt
(10, 20, 30, 'Ding', '  Dong   ')
>>> 
>>> tt = tt + ("Ming", "Mong")
>>> 
>>> tt
(10, 20, 30, 'Ding', '  Dong   ', 'Ming', 'Mong')
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> sheet
((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong'))
>>> 
>>> 
>>> 
>>> tt
(10, 20, 30, 'Ding', '  Dong   ', 'Ming', 'Mong')
>>> 
>>> tt.count("ong")
0
>>> 
>>> tt.count("Mong")
1
>>> 
>>> 
>>> tt[5]
'Ming'
>>> 
>>> tt[5][1]
'i'
>>> 
>>> tt[0]
10
>>> tt[1]
20
>>> tt[2]
30
>>> 
>>> sheet
((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong'))
>>> 
>>> sheet[0
... ]
(1, 'Ding', 'Dong')
>>> sheet[1]
(2, 'Ming', 'Mong')
>>> sheet[2]
(3, 'Ting', 'Tong')
>>> 
>>> sheet[0][2]
'Dong'
>>> sheet[0][2][1]
'o'
>>> 
>>> 
>>> 
>>> 
>>> t
(10, 20, 30, 40, 50, 60, 70, 80, 90)
>>> 
>>> tt
(10, 20, 30, 'Ding', '  Dong   ', 'Ming', 'Mong')
>>> 
>>> 
>>> 
>>> 
>>> tt = (10, 20, (100, 200, (1000, 2000)), ("Ding", "Dong", ("Ming", "Mong")))
>>> 
>>> tt
(10, 20, (100, 200, (1000, 2000)), ('Ding', 'Dong', ('Ming', 'Mong')))
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> tt
(10, 20, (100, 200, (1000, 2000)), ('Ding', 'Dong', ('Ming', 'Mong')))
>>> tt[2]
(100, 200, (1000, 2000))
>>> 
>>> tt[2][2]
(1000, 2000)
>>> 
>>> type(tt[2][2])
<class 'tuple'>
>>> 
>>> type(tt[2][2][1])
<class 'int'>
>>> 
>>> tt[2][2][1]
2000
>>> 
>>> tt[3][2][1]
'Mong'
>>> 
>>> tt[3][2]
('Ming', 'Mong')
>>> 
>>> 
>>> 
>>> sheet
((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong'))
>>> 
>>> workbook = (sheet, sheet, sheet)
>>> 
>>> workbook
(((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong')), ((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong')), ((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong')))
>>> 
>>> 
>>> workbook[0]
((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong'))
>>> workbook[1]
((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong'))
>>> 
>>> workbook[2]
((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong'))
>>> 
>>> workbook[2]
((1, 'Ding', 'Dong'), (2, 'Ming', 'Mong'), (3, 'Ting', 'Tong'))
>>> 
>>> 
>>> dir(greeting)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> 
>>> 


